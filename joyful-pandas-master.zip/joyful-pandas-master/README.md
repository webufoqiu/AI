# Joyful-Pandas

 请在使用教程前确认pandas版本不低于1.2.0

### 网页版

http://joyfulpandas.datawhale.club/

### 大纲

[![DzAqIg.png](https://s3.ax1x.com/2020/12/07/DzAqIg.png)](https://imgchr.com/i/DzAqIg)

### 论坛

http://datawhale.club/c/team-learning/IntroductionToPandas/12

### 文件内容

* data：数据集
* ebook：教程电子版
* notebook：教程notebook版

### 参考资料

* [Python for Data Analysis](<http://93.174.95.29/_ads/A3AD6E6B2504B95EC39A6C57D465BA5D>) Wes McKinney著

* [Pandas Cookbook](<http://93.174.95.29/_ads/23950B4446ABB5DD27168D6B0FB2C8DB>) Theodore Petrou著

* [User Guide](<https://pandas.pydata.org/docs/user_guide/index.html#user-guide>) Pandas开发团队编写

### 交流群

关注Datawhale公众号，回复关键词“熊猫”获得二维码

<img src="source/_static/qrcode.jpeg" width="25%"/>

### LICENSE

<img alt="知识共享许可协议" style="border-width:0" src="https://i.creativecommons.org/l/by-nc-sa/4.0/88x31.png" /></a><br />本作品采用<a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/">知识共享署名-非商业性使用-相同方式共享 4.0 国际许可协议</a>进行许可